#!/bin/bash

./$1
exit 0
